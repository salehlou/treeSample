export interface RightClickItem {
   id: number;
   name: string;
}
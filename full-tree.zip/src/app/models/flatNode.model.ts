export interface FlatNode {
   expandable: boolean;
   name: string;
   level: number;
   checked: boolean;
   nodeIcon: string;
}

export interface TreeData {
   id: number;
   name: string;
   checked: boolean;
   nodeIcon: string;
   parentId: number;
}
